from django.shortcuts import render


import numpy as np
import pandas as pd
import seaborn as sns
#from matplotlib import pyplot as plt
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm, skew
from sklearn.preprocessing import OneHotEncoder,MinMaxScaler,StandardScaler
from sklearn.feature_extraction import DictVectorizer
from sklearn.impute import SimpleImputer
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score
from imblearn.over_sampling import SMOTE
from sklearn.metrics import classification_report
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
from imblearn.pipeline import make_pipeline
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import roc_auc_score
import numpy as np
from sklearn.decomposition import PCA
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score, roc_auc_score
from sklearn.ensemble import VotingClassifier
# Create your views here.


def home(request):

    return render(request,'home.html', {
            'active_menu': 'home',
        })
def homepag_view(request):
    return render(request, 'homepag.html')

def ysdata(request,ysdataName):
    # 设置matplotlib字体
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]  # 设置字体
    plt.rcParams["axes.unicode_minus"] = False  # 正常显示负号
    plt.rcParams.update({'font.size': 16})
    submenu = ysdataName
    if ysdataName=='dataload':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        a='加载数据成功'
        b=0
        return render(
        request, 'ysdata.html', {
            'active_menu': 'ysdata',
            'sub_menu': submenu,
            'productNamea': a,
            'productNameb': b,
        })
    elif ysdataName=='datashow':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        # 显示数据集的前部分数据
        a=data.head(10)
        return render(
        request, 'ysdata.html', {
            'active_menu': 'ysdata',
            'sub_menu': submenu,
            'productNamea': a,
        })
    elif ysdataName=='datadesc':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        # 查看训练数据的信息
        a=data['RES'].describe()
        return render(
        request, 'ysdata.html', {
            'active_menu': 'ysdata',
            'sub_menu': submenu,
            'productNamea': a,
        })
    else:
        if ysdataName=='dataexplore':
            #1加载数据集
            data=pd.read_csv('./医保特征数据.csv')
            data1=pd.read_csv('./医保特征数据.csv')
            #2数据探索
            #RES分布图（正态分布）数据偏度
            sns.distplot(data['RES'])
            plt.savefig('./static/img/fig1.png')
            b1=1
            b2=0
            b3=0
            b5=0
            b7=0
        elif ysdataName== 'datamodify':
            #1加载数据集
            data=pd.read_csv('./医保特征数据.csv')
            data1=pd.read_csv('./医保特征数据.csv')
            # 修正数据
            data['RES'] = np.log1p(data['RES'])
            sns.distplot(data['RES'], fit=norm)
            plt.savefig('./static/img/fig2.png')
            b1=0
            b2=1
            b3=0
            b5=0
            b7=0
        elif ysdataName== 'datalook':
            #1加载数据集
            data=pd.read_csv('./医保特征数据.csv')
            data1=pd.read_csv('./医保特征数据.csv')
            # 修正数据
            data['RES'] = np.log1p(data['RES'])
            #观察分析月就诊天数_MAX
            sns.boxplot(x='月就诊天数_MAX', y='RES', data=data)
            plt.xticks(rotation=90)
            plt.savefig('./static/img/fig3.png')
            #观察分析月就诊医院数_MAX
            sns.scatterplot(x='月就诊医院数_MAX', y='RES', data=data)
            plt.savefig('./static/img/fig4.png')
            #继续观察分析其他特征
            b1=0
            b2=0
            b3=1
            b5=0
            b7=0
        elif ysdataName== 'pairingcorrelation':
            #1加载数据集
            data=pd.read_csv('./医保特征数据.csv')
            data1=pd.read_csv('./医保特征数据.csv')
            # 修正数据
            data['RES'] = np.log1p(data['RES'])
            #分析所有列的成对相关性
            print(data.corr(numeric_only=True)['RES'].sort_values(ascending=False)[1:])
            corrmat = data.corr(numeric_only=True)
            f, ax = plt.subplots(figsize=(12, 9))
            #热力图
            sns.heatmap(corrmat, vmax=.8, square=True)
            plt.savefig('./static/img/fig5.png')
            b1=0
            b2=0
            b3=0
            b5=1
            b7=0
        elif ysdataName== 'correlation':
            #1加载数据集
            data=pd.read_csv('./医保特征数据.csv')
            data1=pd.read_csv('./医保特征数据.csv')
            # 修正数据
            data['RES'] = np.log1p(data['RES'])
            #分析两两特征之间的相关性
            corr = data.corr(numeric_only=True)
            highest_corr_features = corr.index[abs(corr["RES"]) > 0.5]
            plt.figure(figsize=(10, 10))
            #热力图
            g = sns.heatmap(data[highest_corr_features].corr(), annot=True, cmap="RdYlGn")
            plt.savefig('./static/img/fig6.png')
            #矩阵点图
            cols = ['RES', '住院天数_SUM', '药品费自费金额_SUM', '基本个人账户支付_SUM', '个人支付的药品占比',
                    '个人支付治疗费用占比', '治疗费用在总金额占比']
            sns.pairplot(data[cols])
            plt.savefig('./static/img/fig7.png')
            b1=0
            b2=0
            b3=0
            b5=0
            b7=1
        return render(
        request, 'ysdata.html', {
            'active_menu': 'ysdata',
            'sub_menu': submenu,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb5': b5,
            'productNameb7': b7,
        })


def predata(request,predataName):
    # 设置matplotlib字体
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]  # 设置字体
    plt.rcParams["axes.unicode_minus"] = False  # 正常显示负号
    plt.rcParams.update({'font.size': 16})
    submenu = predataName
    if predataName=='qs':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        a1=missing_data.head(10)
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        # 显示缺失值处理的结果
        total = yb_data2.isnull().sum().sort_values(ascending=False)
        a2=total.head(10)
        b1=1
        b2=0
        b3=0
        return render(
        request, 'predata.html', {
            'active_menu': 'predata',
            'sub_menu': submenu,
            'productNamea1': a1,
            'productNamea2': a2,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
        })
    elif predataName=='tzpd':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        a1=high_skew
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        b1=0
        b2=1
        b3=0
        return render(
        request, 'predata.html', {
            'active_menu': 'predata',
            'sub_menu': submenu,
            'productNamea1': a1,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
        })
    elif predataName=='gyh':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)
        a1=data_scaled[:10]
        b1=0
        b2=0
        b3=1
        return render(
        request, 'predata.html', {
            'active_menu': 'predata',
            'sub_menu': submenu,
            'productNamea1': a1,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
        })
    


def feature(request,featureName):
    # 设置matplotlib字体
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]  # 设置字体
    plt.rcParams["axes.unicode_minus"] = False  # 正常显示负号
    plt.rcParams.update({'font.size': 16})
    submenu = featureName
    if featureName=='tzmx':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        a=selected_features
        b1=1
        b2=0
        b3=0
        b4=0
        b5=0
        b6=0
        return render(
        request, 'feature.html', {
            'active_menu': 'feature',
            'sub_menu': submenu,
            'productNamea': a,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
            'productNameb6': b6,
        })
    elif featureName=='zjtz':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features

        b1=0
        b2=1
        b3=0
        b4=0
        b5=0
        b6=0
        return render(
        request, 'feature.html', {
            'active_menu': 'feature',
            'sub_menu': submenu,
            'productNamea': a,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
            'productNameb6': b6,
        })
    elif featureName=='jstz':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features
        #减少觉得不重要，但被选择的特征
        new1_selected_features=new_selected_features.drop(['民政救助补助_SUM','城乡救助补助金额_SUM',])
        #最终选择的特征
        a=new1_selected_features

        b1=0
        b2=0
        b3=1
        b4=0
        b5=0
        b6=0
        return render(
        request, 'feature.html', {
            'active_menu': 'feature',
            'sub_menu': submenu,
            'productNamea': a,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
            'productNameb6': b6,
        })
    elif featureName=='bzh':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features
        #减少觉得不重要，但被选择的特征
        new1_selected_features=new_selected_features.drop(['民政救助补助_SUM','城乡救助补助金额_SUM',])
        # 创建标准化转换器
        scaler = StandardScaler()
        # 选择数据中的20个特征
        features = yb_data2[new1_selected_features]
        # 对这20个特征进行标准化
        features_standardized = scaler.fit_transform(features)
        a=features_standardized
    

        b1=0
        b2=0
        b3=0
        b4=4
        b5=0
        b6=0
        return render(
        request, 'feature.html', {
            'active_menu': 'feature',
            'sub_menu': submenu,
            'productNamea': a,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
            'productNameb6': b6,
        })
    elif featureName=='dxstz':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features
        #减少觉得不重要，但被选择的特征
        new1_selected_features=new_selected_features.drop(['民政救助补助_SUM','城乡救助补助金额_SUM',])
        # 创建标准化转换器
        scaler = StandardScaler()
        # 选择数据中的20个特征
        features = yb_data2[new1_selected_features]
        # 对这20个特征进行标准化
        features_standardized = scaler.fit_transform(features)
        a=features_standardized
        # #构建多项式特征（在原有特征的基础上进行变换得到的特征）
        poly = PolynomialFeatures(degree=2)

        # 对特征进行多项式转换
        features_poly = poly.fit_transform(features_standardized)
        a=features_poly
    

        b1=0
        b2=0
        b3=0
        b4=0
        b5=1
        b6=0
        return render(
        request, 'feature.html', {
            'active_menu': 'feature',
            'sub_menu': submenu,
            'productNamea': a,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
            'productNameb6': b6,
        })
    elif featureName=='zcffx':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features
        #减少觉得不重要，但被选择的特征
        new1_selected_features=new_selected_features.drop(['民政救助补助_SUM','城乡救助补助金额_SUM',])
        # 创建标准化转换器
        scaler = StandardScaler()
        # 选择数据中的20个特征
        features = yb_data2[new1_selected_features]
        # 对这20个特征进行标准化
        features_standardized = scaler.fit_transform(features)
        a=features_standardized
        # #构建多项式特征（在原有特征的基础上进行变换得到的特征）
        poly = PolynomialFeatures(degree=2)

        # 对特征进行多项式转换
        features_poly = poly.fit_transform(features_standardized)
        pca = PCA(n_components=0.95)  # 保留累计方差解释比例为95%的主成分

        # 对特征进行主成分分析
        features_pca = pca.fit_transform(features_poly)
        a=features_pca

    

        b1=0
        b2=0
        b3=0
        b4=0
        b5=0
        b6=1
        return render(
        request, 'feature.html', {
            'active_menu': 'feature',
            'sub_menu': submenu,
            'productNamea': a,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
            'productNameb6': b6,
        })

def model(request,modelName):
    # 设置matplotlib字体
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]  # 设置字体
    plt.rcParams["axes.unicode_minus"] = False  # 正常显示负号
    plt.rcParams.update({'font.size': 16})
    submenu = modelName
        
    if modelName=='hf':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features
        #减少觉得不重要，但被选择的特征
        new1_selected_features=new_selected_features.drop(['民政救助补助_SUM','城乡救助补助金额_SUM',])
        # 创建标准化转换器
        scaler = StandardScaler()
        # 选择数据中的20个特征
        features = yb_data2[new1_selected_features]
        # 对这20个特征进行标准化
        features_standardized = scaler.fit_transform(features)
        a=features_standardized
        # #构建多项式特征（在原有特征的基础上进行变换得到的特征）
        poly = PolynomialFeatures(degree=2)

        # 对特征进行多项式转换
        features_poly = poly.fit_transform(features_standardized)
        pca = PCA(n_components=0.95)  # 保留累计方差解释比例为95%的主成分

        # 对特征进行主成分分析
        features_pca = pca.fit_transform(features_poly)
        #数据集划分
        r=np.random.randint(1,100)
        X_temp, X_test, y_temp, y_test = train_test_split(features_pca,data1['RES'], random_state=r)
        X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, random_state=r)
        a1=len(X_train)
        a2=len(X_test)
        a3=len(X_val)

        b1=1
        b2=0
        b3=0
        b4=0
        b5=0
        return render(
        request, 'model.html', {
            'active_menu': 'model',
            'sub_menu': submenu,
            'productNamea1': a1,
            'productNamea2': a2,
            'productNamea3': a3,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
        })
    elif modelName=='gcy':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features
        #减少觉得不重要，但被选择的特征
        new1_selected_features=new_selected_features.drop(['民政救助补助_SUM','城乡救助补助金额_SUM',])
        # 创建标准化转换器
        scaler = StandardScaler()
        # 选择数据中的20个特征
        features = yb_data2[new1_selected_features]
        # 对这20个特征进行标准化
        features_standardized = scaler.fit_transform(features)
        a=features_standardized
        # #构建多项式特征（在原有特征的基础上进行变换得到的特征）
        poly = PolynomialFeatures(degree=2)

        # 对特征进行多项式转换
        features_poly = poly.fit_transform(features_standardized)
        pca = PCA(n_components=0.95)  # 保留累计方差解释比例为95%的主成分

        # 对特征进行主成分分析
        features_pca = pca.fit_transform(features_poly)
        #数据集划分
        r=np.random.randint(1,100)
        X_temp, X_test, y_temp, y_test = train_test_split(features_pca,data1['RES'], random_state=r)
        X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, random_state=r)
        r=np.random.randint(1,100)
        smote = SMOTE(sampling_strategy=0.3, k_neighbors=5,random_state=r)
        X_train_smote, y_train_smote = smote.fit_resample(X_train, y_train)
        a1=len(X_train_smote)

        b1=0
        b2=1
        b3=0
        b4=0
        b5=0
        return render(
        request, 'model.html', {
            'active_menu': 'model',
            'sub_menu': submenu,
            'productNamea1': a1,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
        })
    elif modelName=='slh':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features
        #减少觉得不重要，但被选择的特征
        new1_selected_features=new_selected_features.drop(['民政救助补助_SUM','城乡救助补助金额_SUM',])
        # 创建标准化转换器
        scaler = StandardScaler()
        # 选择数据中的20个特征
        features = yb_data2[new1_selected_features]
        # 对这20个特征进行标准化
        features_standardized = scaler.fit_transform(features)
        a=features_standardized
        # #构建多项式特征（在原有特征的基础上进行变换得到的特征）
        poly = PolynomialFeatures(degree=2)

        # 对特征进行多项式转换
        features_poly = poly.fit_transform(features_standardized)
        pca = PCA(n_components=0.95)  # 保留累计方差解释比例为95%的主成分

        # 对特征进行主成分分析
        features_pca = pca.fit_transform(features_poly)
        #数据集划分
        r=np.random.randint(1,100)
        X_temp, X_test, y_temp, y_test = train_test_split(features_pca,data1['RES'], random_state=r)
        X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, random_state=r)
        r=np.random.randint(1,100)
        smote = SMOTE(sampling_strategy=0.3, k_neighbors=5,random_state=r)
        X_train_smote, y_train_smote = smote.fit_resample(X_train, y_train)
        #5模型训练

        # 在训练集上拟合模型，模型是逻辑回归模型
        lr = LogisticRegression(C=0.1, penalty='l1', solver='liblinear')
        lr.fit(X_train_smote, y_train_smote)
        a1='逻辑回归模型实例化成功'

        b1=0
        b2=0
        b3=1
        b4=0
        b5=0
        return render(
        request, 'model.html', {
            'active_menu': 'model',
            'sub_menu': submenu,
            'productNamea1': a1,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
        })
    elif modelName=='yzj':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features
        #减少觉得不重要，但被选择的特征
        new1_selected_features=new_selected_features.drop(['民政救助补助_SUM','城乡救助补助金额_SUM',])
        # 创建标准化转换器
        scaler = StandardScaler()
        # 选择数据中的20个特征
        features = yb_data2[new1_selected_features]
        # 对这20个特征进行标准化
        features_standardized = scaler.fit_transform(features)
        a=features_standardized
        # #构建多项式特征（在原有特征的基础上进行变换得到的特征）
        poly = PolynomialFeatures(degree=2)

        # 对特征进行多项式转换
        features_poly = poly.fit_transform(features_standardized)
        pca = PCA(n_components=0.95)  # 保留累计方差解释比例为95%的主成分

        # 对特征进行主成分分析
        features_pca = pca.fit_transform(features_poly)
        #数据集划分
        r=np.random.randint(1,100)
        X_temp, X_test, y_temp, y_test = train_test_split(features_pca,data1['RES'], random_state=r)
        X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, random_state=r)
        r=np.random.randint(1,100)
        smote = SMOTE(sampling_strategy=0.3, k_neighbors=5,random_state=r)
        X_train_smote, y_train_smote = smote.fit_resample(X_train, y_train)
        #5模型训练

        # 在训练集上拟合模型，模型是逻辑回归模型
        lr = LogisticRegression(C=0.1, penalty='l1', solver='liblinear')
        lr.fit(X_train_smote, y_train_smote)
        # # 在验证集上进行预测
        val_predictions = lr.predict(X_val)
        val_probabilities = lr.predict_proba(X_val)[:, 1] 
        # 在验证集上计算性能指标
        val_accuracy = accuracy_score(y_val, val_predictions)
        val_recall = recall_score(y_val, val_predictions)
        val_precision = precision_score(y_val, val_predictions)
        val_f1 = f1_score(y_val, val_predictions)
        val_auc = roc_auc_score(y_val, val_probabilities)
        a1=val_accuracy
        a2=val_recall
        a3=val_precision
        a4=val_f1
        a5=val_auc


        b1=0
        b2=0
        b3=0
        b4=1
        b5=0
        return render(
        request, 'model.html', {
            'active_menu': 'model',
            'sub_menu': submenu,
            'productNamea1': a1,
            'productNamea2': a2,
            'productNamea3': a3,
            'productNamea4': a4,
            'productNamea5': a5,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
        })
    elif modelName=='csj':
        #1加载数据集
        data=pd.read_csv('./医保特征数据.csv')
        data1=pd.read_csv('./医保特征数据.csv')
        #3缺失数据处理
        yb_data1=data.drop(['个人编码', 'RES'], axis=1)
        Total = yb_data1.isnull().sum().sort_values(ascending=False)
        missing_data = pd.concat([Total], axis=1, keys=['Total'])
        #这里要基于行业知识进行判断，有缺失值的这些属性是否与医保欺诈有关系，如果没有关系，可以直接删除这些列，
        #如果有关系，就不能删除，进行缺失值填充，这里先假设没有关系，直接删掉
        yb_data2=yb_data1.drop((missing_data[missing_data['Total'] >= 1]).index, axis=1)
        #4修正特征偏度> 0.5的
        numeric_feats = yb_data2.dtypes[yb_data2.dtypes != 'object'].index
        skewed_feats = yb_data2[numeric_feats].apply(lambda x: skew(x)).sort_values(ascending=False)
        high_skew = skewed_feats[abs(skewed_feats) > 0.5]
        # 修正偏度
        for feature in high_skew.index:
            yb_data2[feature] = np.log1p(yb_data2[feature])
        #缺失值处理，策略中值'median'
        imputer = SimpleImputer(strategy='median')
        #删除一些无用的特征列后填充缺失值
        data_imputed = imputer.fit_transform(data1.drop(['个人编码', 'RES','顺序号_NN','医院编码_NN','交易时间DD_NN','交易时间YYYY_NN',
                                                        '交易时间YYYYMM_NN'], axis=1))


        # 对数据进行缩放，归一化
        scaler = MinMaxScaler()
        data_scaled = scaler.fit_transform(data_imputed)

        #SelectKBest选择重要特征
        k = 20  # 选择的特征数量
        chi2_selector = SelectKBest(chi2, k=k)
        X_kbest_features = chi2_selector.fit_transform(data_scaled, data1['RES'])
        # 获取被选中的特征名
        feature_names = data1.drop(['个人编码', 'RES','医院编码_NN','顺序号_NN','交易时间DD_NN','交易时间YYYY_NN','交易时间YYYYMM_NN'], axis=1).columns
        selected_features = feature_names[chi2_selector.get_support()]
        #增加觉得重要，但没被选择的特征
        extra_feature1 = '月药品金额_MAX'
        new_selected_features = selected_features.append(pd.Index([extra_feature1]))
        a=new_selected_features
        #减少觉得不重要，但被选择的特征
        new1_selected_features=new_selected_features.drop(['民政救助补助_SUM','城乡救助补助金额_SUM',])
        # 创建标准化转换器
        scaler = StandardScaler()
        # 选择数据中的20个特征
        features = yb_data2[new1_selected_features]
        # 对这20个特征进行标准化
        features_standardized = scaler.fit_transform(features)
        a=features_standardized
        # #构建多项式特征（在原有特征的基础上进行变换得到的特征）
        poly = PolynomialFeatures(degree=2)

        # 对特征进行多项式转换
        features_poly = poly.fit_transform(features_standardized)
        pca = PCA(n_components=0.95)  # 保留累计方差解释比例为95%的主成分

        # 对特征进行主成分分析
        features_pca = pca.fit_transform(features_poly)
        #数据集划分
        r=np.random.randint(1,100)
        X_temp, X_test, y_temp, y_test = train_test_split(features_pca,data1['RES'], random_state=r)
        X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, random_state=r)
        r=np.random.randint(1,100)
        smote = SMOTE(sampling_strategy=0.3, k_neighbors=5,random_state=r)
        X_train_smote, y_train_smote = smote.fit_resample(X_train, y_train)
        #5模型训练

        # 在训练集上拟合模型，模型是逻辑回归模型
        lr = LogisticRegression(C=0.1, penalty='l1', solver='liblinear')
        lr.fit(X_train_smote, y_train_smote)
        # 在测试集上进行预测
        test_predictions = lr.predict(X_test)
        test_probabilities = lr.predict_proba(X_test)[:, 1] 



        # 在测试集上计算性能指标
        test_accuracy = accuracy_score(y_test, test_predictions)
        test_recall = recall_score(y_test, test_predictions)
        test_precision = precision_score(y_test, test_predictions)
        test_f1 = f1_score(y_test, test_predictions)
        test_auc = roc_auc_score(y_test, test_probabilities)
        a1=test_accuracy
        a2=test_recall
        a3=test_precision
        a4=test_f1
        a5=test_auc


        b1=0
        b2=0
        b3=0
        b4=0
        b5=1
        return render(
        request, 'model.html', {
            'active_menu': 'model',
            'sub_menu': submenu,
            'productNamea1': a1,
            'productNamea2': a2,
            'productNamea3': a3,
            'productNamea4': a4,
            'productNamea5': a5,
            'productNameb1': b1,
            'productNameb2': b2,
            'productNameb3': b3,
            'productNameb4': b4,
            'productNameb5': b5,
        })

def about(request):

    return render(request,'about.html', {
            'active_menu': 'about',
        })
                
                

                

