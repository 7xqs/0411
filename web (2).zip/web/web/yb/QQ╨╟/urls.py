from django.urls import path
from . import views
app_name='QQ星'
urlpatterns = [
    path('ysdata/<str:ysdataName>', views.ysdata,name='ysdata'),
    path('predata/<str:predataName>', views.predata,name='predata'),
    path('feature/<str:featureName>', views.feature,name='feature'),
    path('model/<str:modelName>', views.model,name='model'),
    path('about/', views.about,name='about'),
    path('homepag/', views.homepag_view, name='homepag'),
]