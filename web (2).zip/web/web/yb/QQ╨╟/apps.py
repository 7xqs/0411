from django.apps import AppConfig


class Qq星Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'QQ星'
